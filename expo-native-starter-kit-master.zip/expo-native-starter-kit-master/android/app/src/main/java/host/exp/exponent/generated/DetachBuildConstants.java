package host.exp.exponent.generated;

// This file is auto-generated. Please don't rename!
public class DetachBuildConstants {

  public static final String DEVELOPMENT_URL = "exp5a9e8e27c6444abebcda9249f5f0fd44://192.168.0.104:19000";

}
