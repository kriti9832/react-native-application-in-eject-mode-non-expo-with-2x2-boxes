export default class DeviceInfoMock {
    static getBrand() {
        return "expo dummy device"
    }
}